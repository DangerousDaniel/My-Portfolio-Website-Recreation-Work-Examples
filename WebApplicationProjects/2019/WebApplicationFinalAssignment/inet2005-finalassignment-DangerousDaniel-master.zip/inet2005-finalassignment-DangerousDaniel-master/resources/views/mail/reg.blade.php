@component('mail::message')

    Your  account has been created.

    Thanks, <br>
    {{config('app.name')}}
@endcomponent
