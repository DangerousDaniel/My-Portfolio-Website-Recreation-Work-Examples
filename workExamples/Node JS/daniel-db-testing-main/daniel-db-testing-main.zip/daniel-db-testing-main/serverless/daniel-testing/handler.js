//Setup
'use strict';
const database = require('./database');
const uuid = require('uuid');
const { AppConfig } = require('aws-sdk');
const conn = database.Connect().connection;

module.exports.hello = async (event) => {
  var num = 'select 56';
  const query = await database.Query(conn, num);
  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        message: 'Go Serverless v2.0! Your function executed successfully! ' + query.result[0]["56"],
        input: event,
      },
      null,
      2
    ),
  };
};

//#region DD Spells
//Get all Data //Function To Get Spells
module.exports.getAllSpells = async (req, res) => {
  console.log(uuid.v4())
  const query = await database.Query(conn, 'select * from spell');
  for(var i in query.result){
    query.result[i].range = query.result[i].spell_range;
  }
  return {
    statusCode: 200,
    body: JSON.stringify(query.result),
    headers : {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true
    }
  }
}

module.exports.getDesc = async (req, res) => {
  const body = JSON.parse(req.body);
  const query = await database.Query(conn, `SELECT descrption as Description FROM spell 
  WHERE id="${body.id}";`);
  return {
    statusCode: 200,
    body: JSON.stringify(query.result),
    headers : {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true
    }
  }
}



//Function To Add To Spells and Return
module.exports.addSpell = async (req, res) => {
  
  //Get params from body
  const body = JSON.parse(req.body);

  //Create Insert Query
  let query = `insert into spell values 
    ("${uuid.v4()}", 
    ${conn.escape(body.name)}, 
    ${conn.escape(body.castingTime)}, 
    ${conn.escape(body.spell_range)}, 
    ${conn.escape(body.components)}, 
    ${conn.escape(body.duration)}, 
    ${conn.escape(body.descrption)}
  )`

  // Await query
  const addRes = await database.Query(conn, query)
  console.log(addRes.error);

  //Select all spells
  let getAll = 'select * from spell'
  var allSpells = await database.Query(conn, getAll);
  console.log(allSpells.error);
  //return spells
  return {
    statusCode: 200,
    body: JSON.stringify(allSpells.result),
    headers : {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true
    }
  }
}
//Function to Update Spell and Return

//Get a row from the database
module.exports.getSpell = async (req, res) => {
  const body = JSON.parse(req.body);

  const query = await database.Query(conn, `select * from spell where id = ${conn.escape(body.id)}`);
  return {
    statusCode: 200,
    body: JSON.stringify(query.result),
    headers : {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true
    }
  }
}

//Function to delete spells and return
module.exports.deleteSpell = async (req, res) => {
  console.log("delete");
  //Get params from body
  const body = JSON.parse(req.body);

  //Database query
  let query  = `delete from spell where id=${conn.escape(body.id)}`

  // Await query
  const deleteRes = await database.Query(conn, query)
  console.log(deleteRes.error);

  //Select all spells
  let getAll = 'select * from spell'
  var allSpells = await database.Query(conn, getAll);
  console.log(allSpells.error);
  
  //return spells
  return {
    statusCode: 200,
    body: JSON.stringify(allSpells.result),
    headers : {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true
    }
  }
}
//#endregion


//#region Meetup Database

//Get all Data
module.exports.getAllMeetups = async (req, res) => {
  const query = await database.Query(conn, 'select * from meetupTable');
  return {
    statusCode: 200,
    body: JSON.stringify(query.result),
    headers : {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true
    }
  }
}

//Add Data
module.exports.addMeetups = async (req, res) => {
  const body = JSON.parse(req.body) // get the body

  //Null Check
  if (!body.meet_title || !body.meetup_image || !body.meetup_address || !body.meetup_description)
  {
      return {
      statusCode: 500,
      body: JSON.stringify({
        message: "please enter the data that was request (title, image, address, and description"
      }),
      headers : {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Credentials': true
      }
    }
  }

  //Insert Data
  const query = `insert into meetupTable 
  (meet_title, meetup_image, meetup_address, meetup_description) values 
  (${conn.escape(body.meet_title)}, 
  ${conn.escape(body.meetup_image)}, 
  ${conn.escape(body.meetup_address)}, 
  ${conn.escape(body.meetup_description)});`

  const addRes = await database.Query(conn, query) 

  //Show Data
  const returnQuary = await database.Query(conn, `SELECT * FROM meetupTable;`)  
  return {
    statusCode: 200,
    body: JSON.stringify(returnQuary.result),
    headers : {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true
    }
  }
}

//#endregion


//#region Task Database 

//get data
module.exports.getAllTask = async (req, res) => {
  const query = await database.Query(conn, 'select * from TaskTable;');
  return {
    statusCode: 200,
    body: JSON.stringify(query.result),
    headers : {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true
    }
  }
}

//Add Data
module.exports.addTask = async (req, res) => {
  const body = JSON.parse(req.body) // get the body

  //Null Check
  if (!body.task_name)
  {
      return {
      statusCode: 500,
      body: JSON.stringify({
        message: "please enter the data that was request (name)."
      }),
      headers : {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Credentials': true
      }
    }
  }

  //Insert Data
  const query = `insert into TaskTable 
  (task_name) values 
  (${conn.escape(body.task_name)});`

  const addRes = await database.Query(conn, query) 

  //Show Data
  const returnQuary = await database.Query(conn, `SELECT * FROM TaskTable;`)  
  return {
    statusCode: 200,
    body: JSON.stringify(returnQuary.result),
    headers : {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true
    }
  }
}

//#endregion


//#region 
//slack command test message
module.exports.testMe = async (event) => {
  var num = 'select 56';
  const query = await database.Query(conn, num);
  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        message: 'Boo, MAm I here' + query.result[0]["56"],
        input: event,
      },
      null,
      2
    ),
  };
};

//slack command 2 hello message
module.exports.testMe2 = async (event) => {
  let strNum = '47'
  const query = await database.Query(conn, strNum);
  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        message: `Can I show only this ${strNum}`,
      },
      null,
      2
    ),
  };
};

//slack command 3 get all
module.exports.getAllTaskList = async (req) => {
  const query = await database.Query(conn, 'select * from TaskTable;');

  let printArray = []

  for (let i in query.result)
  {
    printArray.push(JSON.stringify(query.result[i].task_name))
  }
  
  return {
    statusCode: 200,
    body: JSON.stringify({
      data: printArray,
    }, null, 2),
    headers : {
        'content-type': 'application/x-www-form-urlencoded',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true
    }
  }
}

//slack command 4 agrs
module.exports.getAllTaskListAgr = async (req) => {

  let params;

  params = new URLSearchParams(req.body)

  return {
    statusCode: 200,
    body: JSON.stringify({
      response_type: 'in_channel',
      text: params.get('user_name') + " " + params.get('text'),
    }),
    headers : {
        'content-type': 'application/json',
    }
  }
}



//#endregion

