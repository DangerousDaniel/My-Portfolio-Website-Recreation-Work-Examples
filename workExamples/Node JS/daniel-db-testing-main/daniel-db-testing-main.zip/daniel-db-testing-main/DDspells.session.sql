-- @BLOCK
SELECT * FROM spells;