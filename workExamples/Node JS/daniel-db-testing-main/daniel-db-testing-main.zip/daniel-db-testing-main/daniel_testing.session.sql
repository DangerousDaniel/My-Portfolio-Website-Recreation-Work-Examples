-- @BLOCK 
SELECT * FROM spell;

-- @BLOCK
SELECT descrption as Description FROM spell 
WHERE id="e0a1b710-cde2-46a0-8583-c58ae6144b11";

-- @BLOCK
CREATE TABLE meetupTable (
    meetup_id int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    meet_title VARCHAR(255),
    meetup_image VARCHAR(255),
    meetup_address VARCHAR(255),
    meetup_description TEXT
);

-- @BLOCK
SELECT meetup_image FROM meetupTable;

-- @BLOCK
INSERT into meetupTable (meet_title, meetup_image, meetup_address, meetup_description) VALUES (   
    "This is a second meetup", 
    "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Stadtbild_M%C3%BCnchen.jpg/2560px-Stadtbild_M%C3%BCnchen.jpg", 
    'Meetupstreet 5, 12345 Meetup City', 
    'This is a first, amazing meetup which you definitely should not miss. It will be a lot of fun!'
);

-- @BLOCK
CREATE TABLE TaskTable (
    task_id int UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    task_name varchar(255) not NULL
);

-- @BLOCK 
SELECT * FROM TaskTable;

-- @BLOCK
INSERT INTO TaskTable (task_name) VALUES ('This is task one'), ("This is task two");

 